</head>
<body class="bg-gradient bg-dark bg-opacity-25">
<nav role="navigation" class="navbar navbar-dark navbar-static-top bg-primary bg-gradient">
    <div class="container">
      <div class="navbar-header">
        <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ&pp=ygUXbmV2ZXIgZ29ubmEgZ2l2ZSB5b3UgdXA%3D" class="navbar-brand">Inventory Management System</a>
      </div>
    </div>
  </nav>
	
	<div class="container">
	